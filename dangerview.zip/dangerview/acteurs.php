<?php 

session_start();
if(isset($_SESSION['nom'])){
	$nom =$_SESSION['nom'];
	$prenom =$_SESSION['prenom']; 
	$role = $_SESSION['role'];

}else{
	echo '<script language="Javascript">';
    echo 'document.location.replace("./logout.php")'; // -->
    echo ' </script>';
}
?>

<!DOCTYPE html> 
<html lang="en">
<head>

	<title></title>
	 <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1">
	 <link rel="stylesheet" type="text/css" href="style.css">
	 <?php include 'links.php' ?>

</head>
<body>

<header>
	  <div class="container center-div shadow" >
	  <div class="text-uppercase mb-5">
		
	  </div >
      <div class="container row d-flex flex-row justify-content-center mb-5" >
	  <div class="admin-form shadow p-5">


        <form id="myForm" action="" method="post">
       
        	<center><h3></h3></center><br>

          <div class="form-group">
          <label>Les acteurs:</label>
          <input type="text" class="form-control" id="acteur" placeholder="Saisir un acteur" name="acteur" required>
          </div>

       <button type="submit" name = "enregistrer" class="btn bg-primary">Enregistrer</button>


     </form>

   </div>
   </div> 
   </div>

  </header>




<?php

include_once('db.php');



if(isset($_POST['enregistrer'])){
$acteur = $_POST['acteur'];
$datea = date("d-m-Y H:i");

$sql = "INSERT INTO acteurs (acteur, datea)
VALUES ('$acteur', '$datea')";

if (mysqli_query($conn, $sql)) {

 
    echo '<script language="Javascript">';
    echo 'document.location.replace("./acteursaffiche.php")';
    echo ' </script>';


} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

}else{
	echo "";
}


mysqli_close($conn);

?>





</body>
</html>




