<?php 

session_start();
if(isset($_SESSION['nom'])){
	$nom =$_SESSION['nom'];
	$prenom =$_SESSION['prenom']; 
	$role = $_SESSION['role'];

}else{
	echo '<script language="Javascript">';
    echo 'document.location.replace("./logout.php")';
    echo ' </script>';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

	<title>page administrateur et moderateur</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="style.css">
	<?php include 'links.php' ?>

</head>

<body>
  

<center><a href='page.php' style="font-size:40px; color: #ffc500">retour</a></center>
<center><a href='dangertype.php'><i class="fa fa-plus-square " style="font-size:48px; color: #ffc500"></i></</a></center>
<div class="row">
<div class="col-md-10 col-md-10 offset-1">
	<table class="table table-bordered table-hovered">
	<thead>
		<tr>
		
			<td>Danger</td>
            <td>Date d'enregistrement</td>
            <td>Actions</td>
        </tr>
	</thead>
	<tbody>

		<?php  

      include_once('db.php');




$sql = "SELECT id, danger, dated FROM dangertype";
$result_danger = $conn->query($sql);
while($row = mysqli_fetch_array($result_danger)) { ?>
	
    <tr>
    <td><?php echo $row['danger'] ?></td>
	<td><?php echo $row['dated'] ?></td>
	<td>
  
    <a href="modd.php?id=<?php echo $row['id']?>" class="btn btn-danger"> <i class="fas fa-edit"></i></a>
	<a href="suppd.php?id=<?php echo $row['id']?>" class="btn btn-danger"> <i class="far fa-trash-alt"></i></a>		

    </td>
	</tr>

<?php } ?>	
  

	</tbody>
	</table>

</div>
</div>	



 

</body>
</html>