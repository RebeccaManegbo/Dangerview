<?php 

session_start();
if(isset($_SESSION['nom'])){
  $nom =$_SESSION['nom'];
  $prenom =$_SESSION['prenom']; 
  $role = $_SESSION['role'];

}else{
  echo '<script language="Javascript">';
    echo 'document.location.replace("./logout.php")'; 
    echo ' </script>';
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

  <title>page administrateur et moderateur</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="style.css">
  <?php include 'links.php' ?>

<style>

body {font-family: "Lato", sans-serif;}

.sidebar {
  height: 100%;
  width: 180px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  padding-top: 16px;
}

.sidebar a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 20px;
  color: #818181;
  display: block;
}

.sidebar a:hover {
  color: #f1f1f1;
}

.main {
  margin-left: 180px; 
  padding: 0px 10px;
}

@media screen and (max-height: 450px) {
  .sidebar {padding-top: 15px;}
  .sidebar a {font-size: 18px;}
}

</style>

</head>

<body>

  
    

     <?php
        if($role == 'administrateur'){

      ?>

  <div class="sidebar ">
  <a href="#utilisateurs"><i class="fa fa-users"></i> Utilisateurs</a>
  <a href="logout.php"><i class="fa fa-sign-in" style="font-size:26px"></i> Deconnexion</a>
  </div>

    <div class="main">
    <p>

    <div class="heading text-center text-uppercase text-danger mb-3">
    Bienvenue : <?php echo $nom; ?> <?php echo $prenom; ?> <br></div>


<center>
<div class="container">
  <div class="btn-group">
    <button type="button" class="btn btn-danger"><a href='inscription.php' class="text-body">Enregistrer un utilisateur</a></button>
  </div>
  </div>
  </center>
  <br>
 


    <div class="row">
    <div class="col-md-10 col-md-10 offset-1">

    <table class="table table-bordered table-hovered">

    <thead>

    <tr>
    
      <td>Nom</td>
      <td>Prenoms</td>
      <td>Sexe</td>
      <td>Email</td>
      <td>Role</td>
      <td>Date</td>
      <td>Actions</td>

    </tr>

    </thead>

    <tbody>

    <?php        
      include_once('db.php');
      $sql = "SELECT id, nom, prenom, sexe, email, role, datec FROM utilisateur";
      $result_utilisateur = $conn->query($sql);
      while($row = mysqli_fetch_array($result_utilisateur)) { ?>
  
    <tr>

    <td><?php echo $row['nom'] ?></td>
    <td><?php echo $row['prenom'] ?></td>
    <td><?php echo $row['sexe'] ?></td>
    <td><?php echo $row['email'] ?></td>
    <td><?php echo $row['role'] ?></td>
    <td><?php echo $row['datec'] ?></td>

    <td>
  
    <a href="modinscription.php?id=<?php echo $row['id']?>" class="btn btn-danger"> <i class="fas fa-edit" style="font-size:30px"></i></a>
    <a href="suppinscription.php?id=<?php echo $row['id']?>" class="btn btn-danger"> <i class="far fa-trash-alt" style="font-size:30px"></i></a>    

    </td>

    </tr>

    <?php } ?>

    </tbody>

    </table>

    </div>
    </div>  

    </p>
    </div>
   
    <?php
      }else{
    ?>
    
    <div class="sidebar ">
  <a href="#Danger"><i class=" fas fa-exclamation-circle"></i> Dangers</a>
  <a href="logout.php"><i class="fa fa-sign-in" style="font-size:26px"></i> Deconnexion</a>
  </div>

    <div class="main">
    <p>

    <div class="heading text-center text-uppercase text-danger mb-3">
    Bienvenue : <?php echo $nom; ?> <?php echo $prenom; ?> <br></div>

<center>
<div class="container">
  <div class="btn-group">
    <button type="button" class="btn btn-danger"><a href='formulairedanger.php' class="text-body">Ajouter un danger</a></button>
    <button type="button" class="btn btn-danger"><a href='acteuraffiche.php' class="text-body">Gestion des acteurs</a></button>
    <button type="button" class="btn btn-danger"><a href='typeaffiche.php' class="text-body">Gestion des types de danger</a></button>
    <button type="button" class="btn btn-danger"><a href='lieuaffiche.php' class="text-body">Gestion des lieux</a></button>
  </div>
  </div>
  </center>
  <br>



    

  <div class="row">
<div class="col-md-12 offset-md-0">
  <table class="table table-bordered table-hovered">
  <thead>
    <tr>
    
      <td>Type de danger</td>
      <td>Victime</td>
      <td>Responsable</td>
      <td>Ville</td>
      <td>Libellé</td>
      <td>Source</td>
      <td>Date d'enregistrement</td>
      <td>Actions</td>
        </tr>
  </thead>
  <tbody>

    <?php  

      include_once('db.php');

$sql = "SELECT id, type, victime, responsable, lieutable, libelle, url, dated FROM dangertable";
$result_danger = $conn->query($sql);
while($row = mysqli_fetch_array($result_danger)) { ?>
  
    <tr>
  <td><?php echo $row['type'] ?></td>
  <td><?php echo $row['victime'] ?></td>
  <td><?php echo $row['responsable'] ?></td>
  <td><?php echo $row['lieutable'] ?></td>
  <td><?php echo $row['libelle'] ?></td>
  <td><a href="<?php echo$row['url']?>" target="_blank" class="btn btn-danger"><i class="fas fa-external-link-square-alt"></i></a></td>
  <td><?php echo $row['dated'] ?></td>
  <td>
  
    <a href="moddanger.php?id=<?php echo $row['id']?>" class="btn btn-danger"> <i class="fas fa-edit"></i></a>

  <a href="suppdanger.php?id=<?php echo $row['id']?>" class="btn btn-danger"> <i class="far fa-trash-alt"></i></a>   

    </td>
  </tr>

<?php } ?>  
  

  </tbody>
  </table>

</div>
</div>  




    </p>
    </div>

    <?php
       }
    ?>

     
</body>
</html> 
