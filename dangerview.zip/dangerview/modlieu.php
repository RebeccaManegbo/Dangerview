<?php

include("db.php");

if (isset($_GET['id'])){

$id = $_GET['id'];
$query = "SELECT * FROM lieu WHERE id = $id";
$result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) == 1) {
	$row = mysqli_fetch_array($result);
	$ville = $row['ville'];
	$lat = $row['lat'];
	$lng = $row['lng'];
	$datel = date("d-m-Y H:i:s");
}
 
}

if (isset($_POST['modifier'])){
    $id = $_GET['id'];
    $ville = $_POST['ville'];
    $lat = $_POST['lat'];
    $lng = $_POST['lng'];
	$datel = date("d-m-Y H:i:s");

	$query = "UPDATE lieu SET ville = '$ville', lat = '$lat', datel= '$datel' WHERE id = $id";
	mysqli_query($conn, $query);
	header("Location: lieuaffiche.php");

}

?>



<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="style.css">
	<?php include 'links.php' ?>
	<title></title>
</head>
<body>

<div class="container p-4"></div>
<div class="row">
<div class="col-md-5 mx-auto">
<div class="card card-body">
		<form action="modlieu.php?id=<?php echo $_GET['id']; ?>" method="POST">
			<center><h3>Modifier un lieu</h3></center><br>
			<div class="form-group">
			 <input type="text" name="ville" value="<?php echo $ville; ?>" class="form-control" placeholder="modifier une ville" autofocus required>	
			</div>
            
            <div class="form-group">
			 <input type="text" name="lat" value="<?php echo $lat; ?>" class="form-control" placeholder="modifier une latitude" autofocus required>	
			</div>
          
          <div class="form-group">
			 <input type="text" name="lng" value="<?php echo $lng; ?>" class="form-control" placeholder="modifier une longitude" autofocus required>	
			</div>
            
        <center> <button class="btn bg-danger text-dark" name="modifier">modifier</button> </center>   
			
		</form>

	</div>	
	</div>

</body>
</html>







