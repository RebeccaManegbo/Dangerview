<?php

include("db.php");

if (isset($_GET['id'])){

$id = $_GET['id'];
$query = "SELECT * FROM dangertype WHERE id = $id";
$result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) == 1) {
	$row = mysqli_fetch_array($result);
	$danger = $row['danger'];
	$dated= date("d-m-Y H:i");
}
 
}

if (isset($_POST['modifier'])){
    $id = $_GET['id'];
    $danger = $_POST['danger'];
	$dated= date("d-m-Y H:i");

	$query = "UPDATE dangertype SET danger = '$danger', dated= '$dated' WHERE id = $id";
	mysqli_query($conn, $query);
	header("Location: dangeraffiche.php");

}

?>



<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="style.css">
	<?php include 'links.php' ?>
	<title></title>
</head>
<body>

<div class="container p-4"></div>
<div class="row">
<div class="col-md-5 mx-auto">
<div class="card card-body">
		<form action="modd.php?id=<?php echo $_GET['id']; ?>" method="POST">
			<div class="form-group">
			 <input type="text" name="danger" value="<?php echo $danger; ?>" class="form-control" placeholder="modifier un danger" autofocus required>	
			</div>
 
            <button class="btn btn-success btn-block" name="modifier">modifier</button>
			
		</form>

	</div>	
	</div>

</body>
</html>







