<?php 

session_start();
if(isset($_SESSION['nom'])){
	$nom =$_SESSION['nom'];
	$prenom =$_SESSION['prenom']; 
	$role = $_SESSION['role'];

}else{
	echo '<script language="Javascript">';
    echo 'document.location.replace("./logout.php")'; // -->
    echo ' </script>';
}
?>

<!DOCTYPE html> 
<html lang="en">
<head>

	<title></title>
	 <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1">
	 <link rel="stylesheet" type="text/css" href="style.css">
	 <?php include 'links.php' ?>

</head>
<body>

<header>
	  <div class="container center-div shadow">
	  <div class="text-uppercase mb-5">
		
	  </div>
      <div class="container row d-flex flex-row justify-content-center mb-8">
	  <div class="admin-form shadow p-5">


        <form id="myForm" action="" method="post">
       
          <center><h3>Enregistrer un utilisateur</h3></center><br>

          <div class="form-group">
          <label>Nom:</label>
          <input type="text" class="form-control" id="nom" placeholder="Saisir le nom" name="nom" required>
          </div>

          <div class="form-group">
          <label>Prenoms:</label>
          <input type="text" class="form-control" id="prenom" placeholder="Saisir le prenom" name="prenom" required>
          </div>

          <div class="form-group">
          <label>Sexe:</label>
          <select class="form-control" name = "sexe" id = "sexe" required>
	      <option value = "">Choisissez le sexe</option>
	      <option value = "homme">Homme</option>
	      <option value = "femme">Femme</option>
          </select>	  
          </div>

          <div class="form-group">
          <label>Email:</label>
          <input type="email" class="form-control" id="email" placeholder="Entrer l'email" name="email" required>
          </div>

          <div class="form-group">
          <label>Mot de pass:</label>
          <input type="password" class="form-control" id="pwd" placeholder="Entrer le mot de pass" name="pwd" required>
          </div>

          <div class="form-group">
          <label>Role:</label>
          <select class="form-control" name = "role" id = "role" required>
	      <option value = "">Attribuez un role</option>
	      <option value = "administrateur">Administrateur</option>
	      <option value = "operateur">Operateur</option>
          </select>	  
          </div>

       <center><button type="submit" name = "enregistrer" class="btn bg-danger text-dark">Enregistrer</button></center>


     </form>

   </div>
   </div> 
   </div>

  </header>

    <span id="result"></span>

<?php

include_once('db.php');



if(isset($_POST['enregistrer'])){
$nom = $_POST['nom'];
$prenom = $_POST['prenom'];
$sexe = $_POST['sexe'];
$email = $_POST['email'];
$pwd = md5($_POST['pwd']);
$role = $_POST['role'];
$datec = date("d-m-Y H:i:s");

$sql = "INSERT INTO utilisateur (nom, prenom, sexe, email, pwd, role, datec)
VALUES ('$nom', '$prenom', '$sexe', '$email', '$pwd','$role','$datec')";

if (mysqli_query($conn, $sql)) {

 
    echo '<script language="Javascript">';
    echo 'document.location.replace("./page.php")';
    echo ' </script>';


} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

}else{
	echo "";
}


mysqli_close($conn);

?>





</body>
</html>




