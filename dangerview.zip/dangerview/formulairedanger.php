<?php 

session_start();
if(isset($_SESSION['nom'])){
  $nom =$_SESSION['nom'];
  $prenom =$_SESSION['prenom']; 
  $role = $_SESSION['role'];

}else{
  echo '<script language="Javascript">';
    echo 'document.location.replace("./logout.php")'; // -->
    echo ' </script>';
}



?>

<?php

include_once('db.php');

?>




  <!DOCTYPE html> 
  <html lang="en">
  <head>

  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="style.css">
  <?php include 'links.php' ?>

  </head>
  <body>


  <header>
    <div class="container center-div shadow " >
    <div class="text-uppercase mb-5">
    </div >
    <div class="container row d-flex flex-row justify-content-center mb-8" >
    <div class="admin-form shadow p-5">

      <form id="myForm" action="" method="post">
       <center><h3>Enregistrement un évenement</h3></center><br>

      <div class="form-group">
      <label>Type de danger:</label>
     

      <select class="form-control" name = "type" id = "type" required>
      <option value="" >selectionner un type danger</option>
       <?php
      $sqli = "SELECT * FROM dangertype";
      $result = mysqli_query($conn, $sqli);
      while ($row = mysqli_fetch_array($result)) {
      echo '<option>'.$row['danger'].'</option>';
       }
       ?> 
       </select>
 
             
     </div>
  
      <div class="form-group">
      <label>Victime:</label>
      
      <select class="form-control" name = "victime" id = "victime" required>
      <option value="">selectionner une victime</option>
      <?php
      $sqli = "SELECT * FROM acteurs";
      $result = mysqli_query($conn, $sqli);
      while ($row = mysqli_fetch_array($result)) {
      echo '<option>'.$row['acteur'].'</option>';
      }
       ?> 
      </select>
 
             
      </div>

      <div class="form-group">
      <label>Responsable:</label>
     
      <select class="form-control" name = "responsable" id = "responsable" required>
      <option value="">selectionner un responsable</option>
       <?php
      $sqli = "SELECT * FROM acteurs";
      $result = mysqli_query($conn, $sqli);
      while ($row = mysqli_fetch_array($result)) {
      echo '<option>'.$row['acteur'].'</option>';
      }
       ?> 
      </select>
 
            
     </div>


     <div class="form-group">
     <label>Ville:</label>
    

      <select class="form-control" name = "lieutable" id = "lieutable" required>
      <option value="">selectionner une ville</option>
      <?php
      $sqli = "SELECT * FROM lieu";
      $result = mysqli_query($conn, $sqli);
      while ($row = mysqli_fetch_array($result)) {
      echo '<option>'.$row['ville'].'</option>';
      }
      ?> 
      </select>
 
              
      </div>        

      <div class="form-group">
      <label>Libellé:</label>
      <textarea name="libelle" rows="2" class="form-control" placeholder="Entrer un texte" autofocus  required></textarea>
      </div>


      <div class="form-group">

      <label>Source:</label>
      <input type="url" class="form-control" id="url" placeholder="Saisir la source" name="url" required>
      </div>

      <div class="form-group">

      <label>Date:</label>
      <input type="date" class="form-control" name="date" required>
      </div>

       <center><button type="submit" name = "enregistrer" class="btn bg-danger text-dark">Enregistrer</button></center>


      </form>

    </div>
    </div> 
    </div>

  </header>




<?php

include_once('db.php');



if(isset($_POST['enregistrer'])){
$type = $_POST['type'];
$victime = $_POST['victime'];
$responsable= $_POST['responsable'];
$lieutable = $_POST['lieutable'];
$libelle = $_POST['libelle'];
$url = $_POST['url'];
$dated = date("d-m-Y H:i:s");

$sql = "INSERT INTO dangertable (type, victime, responsable, lieutable, libelle, url, dated)
VALUES ('$type', '$victime', '$responsable', '$lieutable','$libelle','$url', '$dated')";

if (mysqli_query($conn, $sql)) {

 
    echo '<script language="Javascript">';
    echo 'document.location.replace("./page.php")';
    echo ' </script>';


} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

}else{
  echo "";
}


mysqli_close($conn);

?>





</body>
</html>




