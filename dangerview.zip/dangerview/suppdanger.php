<?php

include("db.php");
if (isset($_GET['id'])){

$id = $_GET['id'];
$query = "DELETE FROM dangertable WHERE id = $id";
$result = mysqli_query($conn, $query);
if (!$result) {
 die("failed");

}
 

 echo '<script language="Javascript">';
    echo 'document.location.replace("./page.php")';
    echo ' </script>';
 }


?>