<?php

include("db.php");

if (isset($_GET['id'])){

$id = $_GET['id'];
$query = "SELECT * FROM acteurs WHERE id = $id";
$result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) == 1) {
	$row = mysqli_fetch_array($result);
	$acteur = $row['acteur'];
	$datea = date("d-m-Y H:i:s");
}
 
}

if (isset($_POST['modifier'])){
    $id = $_GET['id'];
    $acteur = $_POST['acteur'];
	$datea = date("d-m-Y H:i:s");

	$query = "UPDATE acteurs SET acteur = '$acteur', datea = '$datea' WHERE id = $id";
	mysqli_query($conn, $query);
	header("Location: acteuraffiche.php");

}

?>



<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="style.css">
	<?php include 'links.php' ?>
	<title></title>
</head>
<body>
<header>
	  <div class="container center-div shadow" >
	  <div class="text-uppercase mb-5">
		
	  </div >
      <div class="container row d-flex flex-row justify-content-center mb-5" >
	  <div class="admin-form shadow p-5">


        <form id="myForm" action="" method="post">
       
        	<center><h3></h3></center><br>

		<form action="modacteur.php?id=<?php echo $_GET['id']; ?>" method="POST">
			<div class="form-group">
	<input type="text" name="acteur" value="<?php echo $acteur; ?>" class="form-control" placeholder="modifier un acteur" autofocus required>	
			</div>
 
        <center>    <button class="btn bg-danger text-dark" name="modifier">modifier</button> </center>
			
		</form>

	  </div>
   </div> 
   </div>

  </header>

</body>
</html>







