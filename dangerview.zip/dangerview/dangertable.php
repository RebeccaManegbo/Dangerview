<?php 

session_start();
if(isset($_SESSION['nom'])){
  $nom =$_SESSION['nom'];
  $prenom =$_SESSION['prenom']; 
  $role = $_SESSION['role'];

}else{
  echo '<script language="Javascript">';
    echo 'document.location.replace("./logout.php")'; // -->
    echo ' </script>';
}



?>

<?php

include_once('db.php');

?>



  <!DOCTYPE html> 
  <html lang="en">
  <head>

  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="style.css">
  <?php include 'links.php' ?>

  </head>
  <body>

  <header>
    <div class="container center-div shadow " >
    <div class="text-uppercase mb-5">
    </div >
    <div class="container row d-flex flex-row justify-content-center mb-8" >
    <div class="admin-form shadow p-5">

      <form id="myForm" action="" method="post">
       <center><h3>Enregistrement des données</h3></center><br>

      <div class="form-group">
      <label>Type de danger:</label>
      <?php

      echo '<select class="form-control" name = "type" id = "type" required>
      <option>selectionner un type danger</option>';
      $sqli = "SELECT * FROM dangertype";
      $result = mysqli_query($conn, $sqli);
      while ($row = mysqli_fetch_array($result)) {
      echo '<option>'.$row['danger'].'</option>';
       }
       echo '</select>';
 
     ?>         
     </div>
  
      <div class="form-group">
      <label>Victime:</label>
      <?php
      echo '<select class="form-control" name = "victime" id = "victime" required>
      <option>selectionner une victime</option>';
      $sqli = "SELECT * FROM acteurs";
      $result = mysqli_query($conn, $sqli);
      while ($row = mysqli_fetch_array($result)) {
      echo '<option>'.$row['acteur'].'</option>';
      }
      echo '</select>';
 
      ?>         
      </div>

      <div class="form-group">
      <label>Responsable:</label>
      <?php
      echo '<select class="form-control" name = "responsable" id = "responsable" required>
      <option>selectionner un responsable</option>';
      $sqli = "SELECT * FROM acteurs";
      $result = mysqli_query($conn, $sqli);
      while ($row = mysqli_fetch_array($result)) {
      echo '<option>'.$row['acteur'].'</option>';
      }
      echo '</select>';
 
     ?>         
     </div>


     <div class="form-group">
     <label>Ville:</label>
     <?php

      echo '<select class="form-control" name = "lieutable" id = "lieutable" required>
      <option>selectionner une ville</option>';
      $sqli = "SELECT * FROM lieu";
      $result = mysqli_query($conn, $sqli);
      while ($row = mysqli_fetch_array($result)) {
      echo '<option>'.$row['ville'].'</option>';
      }
      echo '</select>';
 
      ?>         
      </div>        

      <div class="form-group">
      <label>Libellé:</label>
      <textarea name="libelle" rows="2" class="form-control" placeholder="Entrer un texte" autofocus  required></textarea>
      </div>


      <div class="form-group">
      <label>Source:</label>
      <input type="text" class="form-control" id="source" placeholder="Saisir la source" name="source" required>
      </div>

       <center><button type="submit" name = "enregistrer" class="btn bg-warning text-dark">Enregistrer</button></center>


      </form>

    </div>
    </div> 
    </div>

  </header>




<?php

include_once('db.php');



if(isset($_POST['enregistrer'])){
$type = $_POST['type'];
$victime = $_POST['victime'];
$responsable= $_POST['responsable'];
$lieutable = $_POST['lieutable'];
$libelle = $_POST['libelle'];
$source = $_POST['source'];
$dated = date("d-m-Y H:i");

$sql = "INSERT INTO dangertable (type, victime, responsable, lieutable, libelle, source, dated)
VALUES ('$type', '$victime', '$responsable', '$lieutable','$libelle','$source', '$dated')";

if (mysqli_query($conn, $sql)) {

 
    echo '<script language="Javascript">';
    echo 'document.location.replace("./page.php")';
    echo ' </script>';


} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

}else{
  echo "";
}


mysqli_close($conn);

?>





</body>
</html>




