<?php

include_once('db.php');


if (isset($_GET['id'])){

$id = $_GET['id'];
$query = "SELECT * FROM utilisateur WHERE id = $id";
$result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) == 1) {
  $row = mysqli_fetch_array($result);
  $nom = $row['nom'];
  $prenom = $row['prenom'];
  $sexe = $row['sexe'];
  $email = $row['email'];
  $pwd = $row['pwd'];
  $role = $row['role'];
  $datec= date("d-m-Y H:i");
}
 


}

if(isset($_POST['modifier'])){
  $id = $_GET['id'];
$nom =  $_POST['nom'];
$prenom =  $_POST['prenom'];
$sexe =  $_POST['sexe'];
$email =  $_POST['email'];
$pwd =  $_POST['pwd'];
$role =  $_POST['role'];
$datec = date("d-m-Y H:i:s");


$query = "UPDATE utilisateur SET nom='$nom', prenom='$prenom', sexe='$sexe', email='$email', pwd='$pwd', role='$role', datec='$datec' WHERE id= $id";
  mysqli_query($conn, $query);
  header("Location: page.php");

}


?>



<!DOCTYPE html> 
<html lang="en">
<head>

	<title></title>
	 <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1">
	 <link rel="stylesheet" type="text/css" href="style.css">
	 <?php include 'links.php' ?>

</head>
<body>

<header>
	  <div class="container center-div shadow" >
	  <div class="text-uppercase mb-5">
		
	  </div>
      <div class="container row d-flex flex-row justify-content-center mb-8" >
	  <div class="admin-form shadow p-5">

<form id="myForm" action="modinscription.php?id=<?php echo $_GET['id']; ?>" method="POST">
        	<center><h3>Modifier un utilisateur</h3></center><br>

          <div class="form-group">
          <label>Nom:</label>
          <input type="text" class="form-control" id="nom" placeholder="Saisir le nom" name="nom" required value="<?php echo $nom; ?>" >
          </div>

          <div class="form-group">
          <label>Prenoms:</label>
          <input type="text" class="form-control" id="prenom" placeholder="Saisir le prenom" name="prenom" required value="<?php echo $prenom; ?>" >
          </div>

          <div class="form-group">
          <label>Sexe:</label>
          <select class="form-control" name = "sexe" id = "sexe" required >
         <option value="<?=$sexe?>"><?=$sexe?></option>
         <option value = ""></option>
	      <option value = "Homme">Homme</option>
	      <option value = "Femme">Femme</option>
          </select>	  
          </div>

          <div class="form-group">
          <label>Email:</label>
          <input type="email" class="form-control" id="email" placeholder="Entrer l'email" name="email" required value="<?php echo $email; ?>">
          </div>

          <div class="form-group">
          <label>Mot de pass:</label>
          <input type="password" class="form-control" id="pwd" placeholder="Entrer le mot de pass" name="pwd" value="<?php echo $pwd; ?>">
          </div>

          <div class="form-group">
          <label>Role:</label>
           <select class="form-control" name = "role" id = "role" required>
          <option  value="<?=$role?>"><?=$role?></option>
          <option value = ""></option>
	        <option value = "Administrateur">Administrateur</option>
	       <option value = "Operateur">Operateur</option>
        <option value = "Superviseur">Superviseur</option>

          </select>	  
          </div>

         <center><button type="submit" name = "modifier" class="btn bg-danger text-dark">modifier</button></center>

     </form>

   </div>
   </div> 
   </div>

  </header>


</body>
</html>




