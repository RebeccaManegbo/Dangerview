<?php
session_start();

?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Page de connexion</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="style.css">
	<?php include 'links.php' ?>
    <link rel="stylesheet" type="text/css" href="css/util.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">

</head>
<body>

<div class="limiter">
<div class="container-login100">
<div class="wrap-login100 p-t-85 p-b-20">
<form class="login100-form validate-form" action="" method="POST">
<span class="login100-form-avatar">
<img src="dangerview.jpg" alt="logo">
</span>

<div class="wrap-input100 validate-input m-t-85 m-b-35" >
 <input type="email" class="input100" id="email" name="email" required>
<span class="focus-input100" data-placeholder="Entrer votre email"></span>
</div>

 <div class="wrap-input100 validate-input m-b-50" >
  <input type="password" class="input100" id="pwd" name="pwd" required>
  <span class="focus-input100" data-placeholder="Entrer votre mot de pass"></span>
  </div>

<div class="container-login100-form-btn">
<input type="submit" class="login100-form-btn" value="Connexion" name="Connexion">
</div>
<br>
<div class="container-login100-form-btn">
<a href="#" class="txt2">email ou mot de pass oublié?</a>
</div>


</form>
</div>
</div>
</div>

<?php

include_once('db.php');

if(isset($_POST['Connexion'])){
$email = $_POST['email'];
$pwd = md5($_POST['pwd']);

$sql = "SELECT * FROM utilisateur WHERE email = '$email' AND pwd = '$pwd' ";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  
$row = mysqli_fetch_assoc($result);
	$nom = $row["nom"];
	$prenom = $row["prenom"];
	$role = $row["role"];
   $_SESSION['nom'] = $nom;
   $_SESSION['prenom'] = $prenom;
   $_SESSION['role'] = $role;


		echo '<script language="Javascript">';
        echo 'document.location.replace("./page.php")';
        echo ' </script>';

  
    } else {
 
    }

    }else{
	 
  
    }


    mysqli_close($conn);

    ?> 

</body>
</html>
