<?php 

session_start();
if(isset($_SESSION['nom'])){
	$nom =$_SESSION['nom'];
	$prenom =$_SESSION['prenom']; 
	$role = $_SESSION['role'];

}else{
	echo '<script language="Javascript">';
    echo 'document.location.replace("./logout.php")';
    echo ' </script>';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

	<title>page administrateur et moderateur</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="style.css">
	<?php include 'links.php' ?>

    <style>

body {font-family: "Lato", sans-serif;}

.sidebar {
  height: 100%;
  width: 180px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  padding-top: 16px;
}

.sidebar a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 20px;
  color: #818181;
  display: block;
}

.sidebar a:hover {
  color: #f1f1f1;
}
.main {
  margin-left: 180px; 
  padding: 0px 10px;
}

@media screen and (max-height: 450px) {
  .sidebar {padding-top: 15px;}
  .sidebar a {font-size: 18px;}
}

</style>

</head>

<body>
  
   <div class="sidebar">
  <a href="#Danger"><i class=" fas fa-exclamation-circle"></i> Dangers</a>
  <a href="logout.php"><i class="fa fa-sign-in" style="font-size:26px"></i> Deconnexion</a>
  </div>

   <div class="main">
    <p>


    <div class="heading text-center text-uppercase text-danger mb-3">
    Bienvenue : <?php echo $nom; ?> <?php echo $prenom; ?> <br></div>

<center>
<div class="container">
  <div class="btn-group">
  	<button type="button" class="btn btn-danger"><a href='lieu.php' class="text-body">Ajouter un lieu</a></button>
    <button type="button" class="btn btn-danger"><a href='page.php' class="text-body">Gestion des dangers</a></button>
    <button type="button" class="btn btn-danger"><a href='acteuraffiche.php' class="text-body">Gestion des acteurs</a></button>
    <button type="button" class="btn btn-danger"><a href='typeaffiche.php' class="text-body">Gestion des types de danger</a></button>
  </div>
  </div>
  </center>
  <br>


<div class="row">
<div class="col-md-10 col-md-10 offset-1">
	<table class="table table-bordered table-hovered">
	<thead>
		<tr>
		
			<td>Ville</td>
			<td>Latidude</td>
			<td>Longitude</td>
            <td>Date d'enregistrement</td>
            <td>Actions</td>
        </tr>
	</thead>
	<tbody>

		<?php  

      include_once('db.php');




$sql = "SELECT id, ville, lat, lng, datel FROM lieu";
$result_lieu = $conn->query($sql);
while($row = mysqli_fetch_array($result_lieu)) { ?>
	
    <tr>
    <td><?php echo $row['ville'] ?></td>
	<td><?php echo $row['lat'] ?></td>
	<td><?php echo $row['lng'] ?></td>
	<td><?php echo $row['datel'] ?></td>
	<td>
  
    <a href="modlieu.php?id=<?php echo $row['id']?>" class="btn btn-danger"> <i class="fas fa-edit"></i></a>
	<a href="supplieu.php?id=<?php echo $row['id']?>" class="btn btn-danger"> <i class="far fa-trash-alt"></i></a>		

    </td>
	</tr>

<?php } ?>	
  

	</tbody>
	</table>

</div>
</div>	



 </p>
 </div>
    

</body>
</html>