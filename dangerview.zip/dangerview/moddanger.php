<?php

include("db.php");

if (isset($_GET['id'])){

$id = $_GET['id'];
$query = "SELECT * FROM dangertable WHERE id = $id";
$result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) == 1) {
	$row = mysqli_fetch_array($result);
	$type = $row['type'];
	$victime = $row['victime'];
	$responsable = $row['responsable'];
	$lieutable = $row['lieutable'];
	$libelle = $row['libelle'];
	$url = $row['url'];
	$dated= date("d-m-Y H:i");
}
 
}

if (isset($_POST['modifier'])){
    $id = $_GET['id'];
    $type = $_POST['type'];
    $victime = $_POST['victime'];
    $responsable = $_POST['responsable'];
    $lieutable = $_POST['lieutable'];
    $libelle = $_POST['libelle'];
    $url = $_POST['url'];
	$dated= date("d-m-Y H:i");

	$query = "UPDATE dangertable SET type = '$type', victime = '$victime', responsable = '$responsable', lieutable = '$lieutable', libelle = '$libelle', url = '$url', dated= '$dated' WHERE id = $id";
	mysqli_query($conn, $query);
	header("Location: page.php");

}

?>



  <!DOCTYPE html> 
  <html lang="en">
  <head>

  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="style.css">
  <?php include 'links.php' ?>

  </head>
  <body>

  <header>
    <div class="container center-div shadow " >
    <div class="text-uppercase mb-5">
    </div >
    <div class="container row d-flex flex-row justify-content-center mb-8" >
    <div class="admin-form shadow p-5">

      <form id="myForm" action="moddanger.php?id=<?php echo $_GET['id']; ?>" method="post">
       <center><h3>Modifier un évenement</h3></center><br>

      <div class="form-group">
      <label>Type de danger:</label>
      

      <select class="form-control" name = "type" id = "type" required>
      <option value="<?=$type?>"><?=$type?></option>
      <option value=""></option>
      <?php
      $sqli = "SELECT * FROM dangertype";
      $result = mysqli_query($conn, $sqli);
      while ($row = mysqli_fetch_array($result)) {
      echo '<option>'.$row['danger'].'</option>';
       }
       ?>
       </select>
 
              
     </div>
  
      <div class="form-group">
      <label>Victime:</label>
      
      <select class="form-control" name = "victime" id = "victime" required>
      <option value="<?=$victime?>"><?=$victime?></option>
      <option value=""></option>
      <?php
      $sqli = "SELECT * FROM acteurs";
      $result = mysqli_query($conn, $sqli);
      while ($row = mysqli_fetch_array($result)) {
      echo '<option>'.$row['acteur'].'</option>';
      }
      ?> 
      </select>
 
              
      </div>

      <div class="form-group">
      <label>Responsable:</label>
      
      <select class="form-control" name = "responsable" id = "responsable" required>
      <option value="<?=$responsable?>"><?=$responsable?></option>
      <option value=""></option>
      <?php
      $sqli = "SELECT * FROM acteurs";
      $result = mysqli_query($conn, $sqli);
      while ($row = mysqli_fetch_array($result)) {
      echo '<option>'.$row['acteur'].'</option>';
      }
      ?> 
      </select>
 
             
     </div>


     <div class="form-group">
     <label>Ville:</label>
     

      <select class="form-control" name = "lieutable" id = "lieutable" required >
      <option value="<?=$lieutable?>"><?=$lieutable?></option>
      <option value=""></option>
      <?php
      $sqli = "SELECT * FROM lieu";
      $result = mysqli_query($conn, $sqli);
      while ($row = mysqli_fetch_array($result)) {
      echo '<option>'.$row['ville'].'</option>';
      }
      ?>
      </select>
 
               
      </div>        

      <div class="form-group">
      <label>Libellé:</label>
      <textarea name="libelle" rows="2" class="form-control" placeholder="Entrer un texte" autofocus  required> <?php echo $libelle; ?></textarea>
      </div>


      <div class="form-group">
      <label>Source:</label>
      <input type="url" class="form-control" id="url" placeholder="Saisir la source" name="url" value="<?php echo $url; ?>" required>
      </div>

      
       <div class="form-group">

      <label>Date:</label>
      <input type="date" class="form-control" name="date" value="<?php echo $date; ?>" required>
      </div>

       <center><button type="submit" name = "modifier" class="btn bg-warning text-dark">Modifier</button></center>


      </form>

    </div>
    </div> 
    </div>

  </header>










</body>
</html>




