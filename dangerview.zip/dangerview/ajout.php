<?php 

session_start();
if(isset($_SESSION['nom'])){
	$nom =$_SESSION['nom'];
	$prenom =$_SESSION['prenom']; 
	$role = $_SESSION['role'];

}else{
	echo '<script language="Javascript">';
    echo 'document.location.replace("./logout.php")';
    echo ' </script>';
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>
	<title>page ajout</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="style.css">
	<?php include 'links.php' ?>


	</title>
</head>
<body>

</body>
</html>