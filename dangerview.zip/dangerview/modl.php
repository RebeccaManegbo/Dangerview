<?php

include("db.php");

if (isset($_GET['id'])){

$id = $_GET['id'];
$query = "SELECT * FROM messages WHERE id = $id";
$result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) == 1) {
	$row = mysqli_fetch_array($result);
	$titre = $row['titre'];
	$description = $row['description'];
	$datem= date("d-m-Y H:i");
}
 
}

if (isset($_POST['modifier'])){
    $id = $_GET['id'];
    $titre = $_POST['titre'];
	$description = $_POST['description'];
	$datem= date("d-m-Y H:i");

	$query = "UPDATE messages SET titre = '$titre', description = '$description', datem= '$datem' WHERE id = $id";
	mysqli_query($conn, $query);
	header("Location: messages.php");

}

?>



<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="style.css">
	<?php include 'links.php' ?>
	<title></title>
</head>
<body>

<div class="container p-4"></div>
<div class="row">
<div class="col-md-5 mx-auto">
<div class="card card-body">
		<form action="modm.php?id=<?php echo $_GET['id']; ?>" method="POST">
			<div class="form-group">
			 <input type="text" name="titre" value="<?php echo $titre; ?>" class="form-control" placeholder="modifier un titre" autofocus required>	
			</div>
          
            <div class="form-group">
			 <textarea name="description" rows="2" class="form-control" placeholder="modifier un message" autofocus  required><?php echo $description; ?></textarea>
			</div>
            
            <button class="btn btn-success btn-block" name="modifier">modifier</button>
			
		</form>

	</div>	
	</div>

</body>
</html>







