<?php 

session_start();
if(isset($_SESSION['nom'])){
	$nom =$_SESSION['nom'];
	$prenom =$_SESSION['prenom']; 
	$role = $_SESSION['role'];

}else{
	echo '<script language="Javascript">';
    echo 'document.location.replace("./logout.php")'; // -->
    echo ' </script>';
}
?>

<!DOCTYPE html> 
<html lang="en">
<head>

	<title></title>
	 <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1">
	 <link rel="stylesheet" type="text/css" href="style.css">
	 <?php include 'links.php' ?>

</head>
<body>

<header>
	  <div class="container center-div shadow" >
	  <div class="text-uppercase mb-5">
		
	  </div >
      <div class="container row d-flex flex-row justify-content-center mb-5" >
	  <div class="admin-form shadow p-5">


        <form id="myForm" action="" method="post">
       
        	<center><h3></h3></center><br>

          <div class="form-group">
          <label>Ville:</label>
          <input type="text" class="form-control" id="ville" placeholder="Saisir le nom d'une ville" name="ville" required>
          </div>

          <div class="form-group">
          <label>Latidude:</label>
          <input type="text" class="form-control" id="lat" placeholder="Saisir la latidude" name="lat" required>
          </div>


          <div class="form-group">
          <label>Longitude:</label>
          <input type="text" class="form-control" id="lng" placeholder="Saisir la longitude" name="lng" required>
          </div>

     <center>  <button type="submit" name = "enregistrer" class="btn bg-danger text-dark">Enregistrer</button></center>


     </form>

   </div>
   </div> 
   </div>

  </header>




<?php

include_once('db.php');



if(isset($_POST['enregistrer'])){
$ville = $_POST['ville'];
$lat = $_POST['lat'];
$lng = $_POST['lng'];
$datel = date("d-m-Y H:i:s");

$sql = "INSERT INTO lieu (ville, lat, lng, datel)
VALUES ('$ville', '$lat', '$lng', '$datel')";

if (mysqli_query($conn, $sql)) {

 
    echo '<script language="Javascript">';
    echo 'document.location.replace("./lieuaffiche.php")';
    echo ' </script>';


} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

}else{
	echo "";
}


mysqli_close($conn);

?>





</body>
</html>




