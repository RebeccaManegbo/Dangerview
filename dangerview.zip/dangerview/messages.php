<?php

include("db.php")


?>

<?php 

session_start();
if(isset($_SESSION['nom'])){
	$nom =$_SESSION['nom'];
	$prenom =$_SESSION['prenom']; 
	$role = $_SESSION['role'];

}else{
	echo '<script language="Javascript">';
    echo 'document.location.replace("./logout.php")'; // -->
    echo ' </script>';
}
?>


<!DOCTYPE html>
<html>
<head>

	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="style.css">
	<?php include 'links.php' ?>
	<title>page message</title>
	<style>
body {font-family: "Lato", sans-serif;}

.sidebar {
  height: 100%;
  width: 180px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  padding-top: 16px;
}

.sidebar a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 20px;
  color: #818181;
  display: block;
}

.sidebar a:hover {
  color: #f1f1f1;
}

.main {
  margin-left: 180px; /* Same as the width of the sidenav */
  padding: 0px 10px;
}

@media screen and (max-height: 450px) {
  .sidebar {padding-top: 15px;}
  .sidebar a {font-size: 18px;}
}
</style>

</head>
<body>


<div class="sidebar ">
  <a href="page.php"><i class="fa fa-users"></i> Utilisateurs</a>
  <a href="#messages"><i class="fa fa-fw fa-envelope"></i> Messages</a>
  <a href="logout.php"><i class="fa fa-sign-in" style="font-size:26px"></i> Deconnexion</a>
</div>
<div class="main">
 <p>

<div class="heading text-center text-uppercase text-danger mb-2">
    Bienvenue : <?php echo $nom; ?> <?php echo $prenom; ?> <br></div>
 
<div class="container p-3"></div>

<div class="row">

<div class="col-md-10 col-md-10 offset-1">


 <div class="col-md-5 my-4">
	<div class="card card-body">

		<form action="" method="POST">
			<div class="form-group">
			 <input type="text" name="titre" class="form-control" placeholder="Entrer un titre" autofocus required>	
			</div>
          
            <div class="form-group">
			 <textarea name="description" rows="2" class="form-control" placeholder="Entrer un message" autofocus  required></textarea>
			</div>
            
            <input type="submit" class="btn bg-warning text-dark btn-block" name="envoyer">
			
		</form>
     
	</div>
	</div>	
	</div>

    <div class="col-md-10 col-md-10 offset-1">
	<table class="table table-bordered table-hovered">
	
	<thead>
		<tr>
			<th>Titre</th>
			<th>Description</th>
			<th>Date</th>
			<th>Actions</th>
		</tr>
	</thead>
<tbody>
<?php

$query = "SELECT * FROM messages";
$result_messages = mysqli_query($conn, $query);

while($row = mysqli_fetch_array($result_messages)) { ?>
<tr>
	<td><?php echo $row['titre'] ?></td>
	<td><?php echo $row['description'] ?></td>
	<td><?php echo $row['datem'] ?></td>
	<td>
	<a href="modm.php?id=<?php echo $row['id']?>" style="font-size:30px; color: #ffc500"> <i class="fas fa-edit"></i></a>
	<a href="suppm.php?id=<?php echo $row['id']?>" style="font-size:30px; color: #ffc500"> <i class="far fa-trash-alt"></i></a>		
	</td>
</tr>

<?php } ?>	

</tbody>
</table>

  </div>
  </p>
</div>
 

<?php

if (isset($_POST['envoyer'])){
 $titre = $_POST['titre'];
 $description = $_POST['description'];
 $datem= date("d-m-Y H:i");

 $sql = "INSERT INTO messages (titre, description, datem) VALUES ('$titre', '$description', '$datem')";
if (mysqli_query($conn, $sql)) {

    echo '<script language="Javascript">';
    echo 'document.location.replace("./messages.php")';
    echo ' </script>';

} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

}else{  
    
}


mysqli_close($conn);

?>


</body>
</html>














